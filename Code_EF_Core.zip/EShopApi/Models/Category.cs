﻿using System.ComponentModel.DataAnnotations;

namespace EShopApi.Models
{
    public class Category
    {
        [Key]  // Chỉ định Primary Key
        public int Id { get; set; }

        [Required]  // Bắt buộc không được null
        [MaxLength(100)]  // Giới hạn độ dài tối đa 100 ký tự
        public string Name { get; set; } = string.Empty;

        [MaxLength(500)]
        public string? Description { get; set; }  // Optional (nullable)

        [Required]
        public DateTime CreatedAt { get; set; }  // Ngày tạo danh mục

        // Quan hệ 1-N với Product
        public ICollection<Product> Products { get; set; } = new List<Product>();
    }
}