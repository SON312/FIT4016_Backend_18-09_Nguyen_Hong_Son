﻿using Microsoft.EntityFrameworkCore;
using EShopApi.Models;

namespace EShopApi.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<Category> Categories { get; set; } = null!;
        public DbSet<Product> Products { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Product>(entity =>
            {
                // Tên bảng
                entity.ToTable("Products");

                // Khóa chính
                entity.HasKey(p => p.Id);

                // Name: bắt buộc, tối đa 200 ký tự
                entity.Property(p => p.Name)
                      .IsRequired()
                      .HasMaxLength(200);

                // Description: tối đa 2000 ký tự
                entity.Property(p => p.Description)
                      .HasMaxLength(2000);

                // Price: decimal(18,2)
                entity.Property(p => p.Price)
                      .HasColumnType("decimal(18,2)");

                // Stock: bắt buộc
                entity.Property(p => p.Stock)
                      .IsRequired();

                // CreatedAt: bắt buộc
                entity.Property(p => p.CreatedAt)
                      .IsRequired();

                // IsDeleted: giá trị mặc định = false
                entity.Property(p => p.IsDeleted)
                      .HasDefaultValue(false);

                // Quan hệ 1-N: Category - Products
                entity.HasOne(p => p.Category)
                      .WithMany(c => c.Products)
                      .HasForeignKey(p => p.CategoryId);
            });
        }
    }
}