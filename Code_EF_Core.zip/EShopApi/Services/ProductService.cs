﻿using Microsoft.EntityFrameworkCore;
using EShopApi.Data;
using EShopApi.Models;

public class ProductService
{
    private readonly AppDbContext _context;

    public ProductService(AppDbContext context)
    {
        _context = context;
    }

    // CREATE — Thêm sản phẩm mới
    public async Task<Product> CreateAsync(Product product)
    {
        // 1. Set CreatedAt = DateTime.UtcNow
        product.CreatedAt = DateTime.UtcNow;

        // 2. Thêm product vào DbSet
        _context.Products.Add(product);

        // 3. Lưu vào Database
        await _context.SaveChangesAsync();

        // 4. Return product
        return product;
    }

    // READ — Lấy tất cả sản phẩm (có Include Category)
    public async Task<List<Product>> GetAllAsync()
    {
        // 1. Lấy tất cả sản phẩm từ Database
        // 2. Include thông tin Category
        // 3. Sắp xếp theo tên (OrderBy)
        // 4. Return list
        return await _context.Products
            .Include(p => p.Category)
            .OrderBy(p => p.Name)
            .ToListAsync();
    }

    // READ — Lấy 1 sản phẩm theo ID (có Include Category)
    public async Task<Product?> GetByIdAsync(int id)
    {
        // 1. Tìm sản phẩm với id đã cho
        // 2. Include thông tin Category
        // 3. Return product hoặc null nếu không tìm thấy
        return await _context.Products
            .Include(p => p.Category)
            .FirstOrDefaultAsync(p => p.Id == id);
    }

    // UPDATE — Cập nhật sản phẩm
    public async Task<Product> UpdateAsync(int id, Product updateData)
    {
        // 1. Tìm sản phẩm với id đã cho
        var product = await _context.Products.FindAsync(id);

        // 2. Throw exception nếu không tìm thấy
        if (product == null)
        {
            throw new Exception("Product not found");
        }

        // 3. Cập nhật các properties
        product.Name = updateData.Name;
        product.Price = updateData.Price;
        product.Stock = updateData.Stock;
        product.CategoryId = updateData.CategoryId;

        // 4. Set UpdatedAt = DateTime.UtcNow
        product.UpdatedAt = DateTime.UtcNow;

        // 5. Lưu vào Database
        await _context.SaveChangesAsync();

        // 6. Return product đã cập nhật
        return product;
    }

    // DELETE — Xóa sản phẩm (Soft Delete)
    public async Task DeleteAsync(int id)
    {
        // 1. Tìm sản phẩm với id đã cho
        var product = await _context.Products.FindAsync(id);

        // 2. Throw exception nếu không tìm thấy
        if (product == null)
        {
            throw new Exception("Product not found");
        }

        // 3. Set IsDeleted = true
        product.IsDeleted = true;

        // 4. Set DeletedAt = DateTime.UtcNow
        product.DeletedAt = DateTime.UtcNow;

        // 5. Lưu vào Database
        await _context.SaveChangesAsync();
    }
    // SEARCH & FILTER
    public async Task<List<Product>> SearchAsync(string? searchTerm, int? categoryId)
    {
        // 1. Bắt đầu query từ _context.Products
        var query = _context.Products.AsQueryable();

        // 2. Nếu searchTerm không null → Where
        if (!string.IsNullOrEmpty(searchTerm))
        {
            query = query.Where(p => p.Name.Contains(searchTerm));
        }

        // 3. Nếu categoryId có giá trị → Where
        if (categoryId.HasValue)
        {
            query = query.Where(p => p.CategoryId == categoryId.Value);
        }

        // 4. Include Category
        query = query.Include(p => p.Category);

        // 5. Return list kết quả
        return await query.ToListAsync();
    }
}